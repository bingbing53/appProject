# 0.3.1

- Add TypeScript type definiation from @vlad-ro

# 0.3.0

- Add config option `appendToBody` to support IE

# 0.2.1

- Fix VueClipboard.config is undefined

# 0.2.0

- Add config option `autoSetContainer`

# 0.1.1

- Move vue to peerDependency
- Fix links in npmjs page

# 0.1.0

Add support for `contianer` option from `clipboard.js` v1.7.0, thanks robmazur

# 0.0.9

Upgrade dependency package version

# 0.0.8

Change vue dependency version to ^2.0.0

# 0.0.7

Add method: this.$copyText

# 0.0.6

Add error handler `v-clipboard:error`

# 0.0.5

Add success handler `v-clipboard:success`

# 0.0.3

Add pre-built version for browser

# 0.0.1

First usable version
